def consolelog(s: str) -> None:
    print("^^^^^^^^^^^^^^^^^^^^")
    print(s)

    print("--------------------")
    print()